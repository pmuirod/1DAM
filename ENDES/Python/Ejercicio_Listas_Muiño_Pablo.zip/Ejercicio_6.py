# Crea un programa que pida al usuario un número de mes (por ejemplo, el 4) y diga cuántos días tiene (por ejemplo, 30) y el nombre del mes. 
# Debes usar listas. Para simplificarlo vamos a suponer que febrero tiene 28 días.
# Por: Pablo Muiño Rodríguez

lista1_muiño = []

print("Escriba un número de mes")
numero_muiño = int(input())
print("Escriba cuánto días tiene")
dias_muiño = int(input())
print("Escriba del nombre del mes")
nombre_muiño = input()

if (numero_muiño==1) and (dias_muiño==31) and (nombre_muiño=="Enero"):
    lista1_muiño.append(dias_muiño)
    lista1_muiño.append(nombre_muiño)
    lista1_muiño.append(numero_muiño)
    print(lista1_muiño)
else:
    print("Se han introducido mal los datos")

if (numero_muiño==2) and (dias_muiño==28) and (nombre_muiño=="Febrero"):
    lista1_muiño.append(dias_muiño)
    lista1_muiño.append(nombre_muiño)
    lista1_muiño.append(numero_muiño)
    print(lista1_muiño)
else:
    print("Se han introducido mal los datos")

if (numero_muiño==3) and (dias_muiño==31) and (nombre_muiño=="Marzo"):
    lista1_muiño.append(dias_muiño)
    lista1_muiño.append(nombre_muiño)
    lista1_muiño.append(numero_muiño)
    print(lista1_muiño)
else:
    print("Se han introducido mal los datos")

if (numero_muiño==4) and (dias_muiño==30) and (nombre_muiño=="Abril"):
    lista1_muiño.append(dias_muiño)
    lista1_muiño.append(nombre_muiño)
    lista1_muiño.append(numero_muiño)
    print(lista1_muiño)
else:
    print("Se han introducido mal los datos")

if (numero_muiño==5) and (dias_muiño==31) and (nombre_muiño=="Mayo"):
    lista1_muiño.append(dias_muiño)
    lista1_muiño.append(nombre_muiño)
    lista1_muiño.append(numero_muiño)
    print(lista1_muiño)
else:
    print("Se han introducido mal los datos")

if (numero_muiño==6) and (dias_muiño==30) and (nombre_muiño=="Junio"):
    lista1_muiño.append(dias_muiño)
    lista1_muiño.append(nombre_muiño)
    lista1_muiño.append(numero_muiño)
    print(lista1_muiño)
else:
    print("Se han introducido mal los datos")

if (numero_muiño==7) and (dias_muiño==31) and (nombre_muiño=="Julio"):
    lista1_muiño.append(dias_muiño)
    lista1_muiño.append(nombre_muiño)
    lista1_muiño.append(numero_muiño)
    print(lista1_muiño)
else:
    print("Se han introducido mal los datos")

if (numero_muiño==8) and (dias_muiño==31) and (nombre_muiño=="Agosto"):
    lista1_muiño.append(dias_muiño)
    lista1_muiño.append(nombre_muiño)
    lista1_muiño.append(numero_muiño)
    print(lista1_muiño)
else:
    print("Se han introducido mal los datos")

if (numero_muiño==9) and (dias_muiño==30) and (nombre_muiño=="Septiembre"):
    lista1_muiño.append(dias_muiño)
    lista1_muiño.append(nombre_muiño)
    lista1_muiño.append(numero_muiño)
    print(lista1_muiño)
else:
    print("Se han introducido mal los datos")

if (numero_muiño==10) and (dias_muiño==31) and (nombre_muiño=="Octubre"):
    lista1_muiño.append(dias_muiño)
    lista1_muiño.append(nombre_muiño)
    lista1_muiño.append(numero_muiño)
    print(lista1_muiño)
else:
    print("Se han introducido mal los datos")

if (numero_muiño==11) and (dias_muiño==30) and (nombre_muiño=="Noviembre"):
    lista1_muiño.append(dias_muiño)
    lista1_muiño.append(nombre_muiño)
    lista1_muiño.append(numero_muiño)
    print(lista1_muiño)
else:
    print("Se han introducido mal los datos")
    
if (numero_muiño==12) and (dias_muiño==31) and (nombre_muiño=="Diciembre"):
    lista1_muiño.append(dias_muiño)
    lista1_muiño.append(nombre_muiño)
    lista1_muiño.append(numero_muiño)
    print(lista1_muiño)
else:
    print("Se han introducido mal los datos")