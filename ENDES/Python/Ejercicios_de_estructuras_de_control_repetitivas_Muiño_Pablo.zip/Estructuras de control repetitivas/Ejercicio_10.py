# Algoritmo que muestre la tabla de multiplicar de los números 1,2,3,4 y 5.
# Por: Pablo Muiño Rodríguez

contador_muiño = 1
producto_muiño = 0
num_muiño = 1

print("La tabla del 1:")

while (num_muiño==1) & (contador_muiño<=10):
    producto_muiño = num_muiño*contador_muiño
    print(producto_muiño)
    contador_muiño = contador_muiño+1

print("La tabla del 2:")
num_muiño = 2
contador_muiño = 1
producto_muiño = 0

while (num_muiño==2) & (contador_muiño<=10):
    producto_muiño = num_muiño*contador_muiño
    print(producto_muiño)
    contador_muiño = contador_muiño+1

print("La tabla del 3:")
num_muiño = 3
contador_muiño = 1
producto_muiño = 0

while (num_muiño==3) & (contador_muiño<=10):
    producto_muiño = num_muiño*contador_muiño
    print(producto_muiño)
    contador_muiño = contador_muiño+1

print("La tabla del 4:")
num_muiño = 4
contador_muiño = 1
producto_muiño = 0

while (num_muiño==4) & (contador_muiño<=10):
    producto_muiño = num_muiño*contador_muiño
    print(producto_muiño)
    contador_muiño = contador_muiño+1

print("La tabla del 5:")
num_muiño = 5
contador_muiño = 1
producto_muiño = 0

while (num_muiño==5) & (contador_muiño<=10):
    producto_muiño = num_muiño*contador_muiño
    print(producto_muiño)
    contador_muiño = contador_muiño+1