# Calcular la media de tres números pedidos por teclado.

num1 = int(input("Escriba un número: "))
num2 = int(input("Escriba un número: "))
num3 = int(input("Escriba un número: "))

media = (num1+num2+num3)/3

print("La media de los 3 números anteriores es",media)