# Una tienda ofrece un descuento del 15% sobre el total de la compra y un cliente desea saber cuanto deberá pagar finalmente por su compra.

precio_inicial = int(input("Introduzca el valor de su compra"))

precio_final = precio_inicial-(precio_inicial*0.15)

print("El precio final (realizando un descuento del 15%) es"+precio_final)