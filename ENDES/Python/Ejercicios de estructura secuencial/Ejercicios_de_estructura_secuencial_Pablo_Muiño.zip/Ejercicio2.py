# Calcular el perímetro y área de un rectángulo dada su base y su altura.

num1 = int(input("Dime la base de un rectángulo: "))
num2 = int(input("Dime la altura de un rectángulo: "))

perimetro = (num1*2)+(num2*2)
area = num1*num2

print = ("El perímetro de un rectángulo de base",num1,"y altura",num2,"es",perimetro)
print = ("El area de un rectángulo de base",num1,"y altura",num2,"es",area)