# Dados dos números, mostrar la suma, resta, división y multiplicación de ambos.

num1 = int(input("Dime un número: "))
num2 = int(input("Dime otro número: "))

suma = num1+num2
resta = num1-num2
division = num1/num2
multiplicacion = num1*num2

print("La suma de los números es",suma)
print("La resta de los números es",resta)
print("La división de los números es",division)
print("La multiplicación de los números es",multiplicacion)