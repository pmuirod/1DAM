# Pedir el nombre y los dos apellidos de una persona y mostrar las iniciales.

print("Escriba su nombre y a continuación sus apellidos")
nombre = input()
apellido1 = input()
apellido2 = input()

print("Las iniciales son",nombre[1],apellido1[1],apellido2[1])