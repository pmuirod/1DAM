# Escribir un programa que convierta un valor dado en grados Fahrenheit a grados Celsius.

fahrenheit = int(input("Escriba un valor en grador Fahrenheit: "))

celsius = (fahrenheit-32)*5/9

print("Los grados celsius del valor anteior son",celsius)