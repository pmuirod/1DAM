# Un alumno desea saber cual será su calificación final en la materia de Algoritmos. Dicha calificación se compone de los siguientes porcentajes:
#   55% del promedio de sus tres calificaciones parciales.
#   30% de la calificación del examen final.
#   15% de la calificación de un trabajo final.

print("Escriba sus tres calificaciones parciales")
cal_1 = input()
cal_2 = input()
cal_3 = input()

print(cal_1)
print(cal_2)
print(cal_3)