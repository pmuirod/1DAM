# Realizar un programa que dada una cadena de caracteres por caracteres, genere otra cadena resultado de invertir la primera.
# Por: Pablo Muiño Rodríguez

print("Escriba una cadena")
cadena_muiño = input()

cadena_muiño = cadena_muiño[::-1]

print(cadena_muiño)