# Escribir por pantalla cada carácter de una cadena introducida por teclado.
# Por: Pablo Muiño Rodríguez

print("Introduzca una cadena")
cadena_muiño = input()

for caracter in cadena_muiño:
    print(caracter)