# Realizar un programa que comprueba si una cadena leída por teclado comienza por una subcadena introducida por teclado.
# Por: Pablo Muiño Rodríguez

print("Introduzca una subcadena")
subcadena_muiño = input()
print("Introduzca una cadena")
cadena_muiño = input()

if subcadena_muiño in cadena_muiño:
    print("La subcadena está en la cadena")
else:
    print("La subcadena no está en la cadena")