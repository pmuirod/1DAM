# Pablo Muiño Rodríguez
# Crea un programa que pida dos números enteros al usuario y diga si alguno de ellos es múltiplo del otro. Crea una función EsMultiplo que reciba los dos números, y devuelve si el primero es múltiplo del segundo.

from Funciones.Funcion2 import EsMultiplo

n1_muino = int(input("Escriba un número entero: "))
n2_muino = int(input("Escriba otro número entero: "))

EsMultiplo(n1_muino,n2_muino)