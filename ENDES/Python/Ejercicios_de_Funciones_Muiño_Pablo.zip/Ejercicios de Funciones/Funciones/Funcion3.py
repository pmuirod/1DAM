# Pablo Muiño Rodríguez
# Módulo para calcular la media de temperatura de un día

def mediaTemperatura(temp_maxima, temp_minima):
    print("La media es de",(temp_maxima+temp_minima)/2,"grados centígrados")