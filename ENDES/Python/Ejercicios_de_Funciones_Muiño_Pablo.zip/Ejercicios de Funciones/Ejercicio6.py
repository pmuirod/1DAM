# Diseñar una función que calcule el área y el perímetro de una circunferencia. Utiliza dicha función en un programa principal que lea el radio
# de una circunferencia y muestre su área y perímetro.

from Funciones.Funcion6 import calcularAreaPerimetro

print("Indique el radio de una circunferencia")
r_muino = int(input())

calcularAreaPerimetro(r_muino)