# Pablo Muiño Rodríguez
# Realice un programa que reciba de nuevo el fichero calificaciones.csv para añadir a cada lista de cada alumno un nuevo elemento, será la Nota Final del curso. 
# El peso de cada parcial de teoría en la nota final es de un 30% mientras que el peso del examen de prácticas es de un 40%. 
# Si el alumno ha realizado alguna recuperación ordinaria, para el cálculo de la nota final se tomará esta como última nota del alumno. 
# Se deberá mostrar finalmente en la terminal la lista ordenada y será guardada en un fichero que se llamará calificacionfinal.csv