# Escribe un programa que lea un número e indique si es par o impar.
# Por: Pablo Muiño Rodríguez

print ("Escriba un número")
num = int(input())

if num%2==0:
    print("El número es par")
else:
    print("El número es impar")