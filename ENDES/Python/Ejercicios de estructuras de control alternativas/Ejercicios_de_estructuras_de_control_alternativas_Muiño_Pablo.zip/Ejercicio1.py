# Algoritmo que pida dos números e indique si el primero es mayor que el segundo o no.
# Por: Pablo Muiño Rodríguez

print ("Escriba dos números")
num1 = int (input())
num2 = int (input())

if num1>num2:
    print("El primer número es mayor que el segundo")
else:
    print("El segundo número es mayor que el primero")