/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examenejercicio2;

/**
 *
 * @author Pablo Muiño Rodríguez
 */
public class Libro {
    //Variables generales
    private String coleccion;
    
    //Variables de instancia
    private final int ISBN, paginas;
    private final String titulo, autor, nacionalidad;
    
    //---*Constructores*---
    public Libro(int ISBN, String titulo, String autor, String nacionalidad, int paginas, String coleccion) {
        this.ISBN = ISBN;
        this.titulo = titulo;
        this.autor = autor;
        this.nacionalidad = nacionalidad;
        this.paginas = paginas;
        this.coleccion = coleccion;
    }//Constructor
    
    //---*Getters y Setters*---
    public int getISBN(){
        return ISBN;
    }//getISBN
    
    public String getTitulo(){
        return titulo;
    }//getTitulo
    
    public String getAutor(){
        return autor;
    }//getAutor
    
    public String getNacionalidad(){
        return nacionalidad;
    }//getNacionalidad
    
    public int getPaginas(){
        return paginas;
    }//getPaginas
    
    public String getColeccion(){
        return coleccion;
    }//getColeccion
    
    public void setColeccion(String coleccion){
        this.coleccion = coleccion;
    }//setColeccion
    
    //---*Métodos*---
    public void imprimirDatos(){
        System.out.println("El libro '"+titulo+"' con ISBN "+ISBN+" creado por el autor "+autor+" de "+nacionalidad+" tiene "+paginas+" páginas.");
    }//imprimirDatos
    
    public void compararPaginas(Libro l){
        if (l.paginas>paginas) {
            System.out.println(l.getTitulo()+" tiene más páginas que "+titulo);
        }else{
            System.out.println(titulo+" tiene más páginas que "+l.getTitulo());
        }//ifelse
    }//compararPaginas
    
}//Libro
