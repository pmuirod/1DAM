/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package examenejercicio2;

/**
 *
 * @author Pablo Muiño Rodríguez
 */
public class Main {

    public static void main(String[] args) {
        //Se crean 2 ibros
        Libro l1 = new Libro(123456789,"El burro pequeño","Miguel de Cervantes","España",98,"Cuentos infantiles");
        Libro l2 = new Libro(987654321,"La piña elegante","Teressa Griffin","Reino Unido",54,"Novela");
        
        //Se crea el contenido de la clase main
        l1.imprimirDatos();
        l2.imprimirDatos();
        l1.compararPaginas(l2);
        
    }//main
}//Main
