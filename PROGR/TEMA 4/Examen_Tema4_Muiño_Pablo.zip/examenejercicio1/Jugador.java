/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examenejercicio1;

/**
 *
 * @author Pablo Muiño Rodríguez
 */
public class Jugador {
    //Variables generales
    private int puntos, faltas, posicion, numPuntos;
    
    //Variables de instancia
    private final String nombreJugador;
    private final double altura;
    
    //Variables de clase
    private static boolean expulsado = false, banquillo = true;
    
    //---*Constructores*---
    public Jugador(String nombreJugador, double altura) {
        this.nombreJugador = nombreJugador;
        this.altura = altura;
    }//Constructor1
    
    public Jugador(String nombreJugador, double altura, int posicion) {
        this.nombreJugador = nombreJugador;
        this.altura = altura;
        this.posicion = posicion;
    }//Constructor2
    
    //---*Getters y Setters*---
    public int getPuntos(){
        return puntos;
    }//getPuntos
    
    public double getAltura(){
        return altura;
    }//getAltura
    
    public int getFaltas(){
        return faltas;
    }//getFaltas
    
    public String getNombreJugador(){
        return nombreJugador;
    }//getNombre
    
    public int getPosicion(){
        return posicion;
    }//getFaltas
    
    //---*Métodos*---
    public void sumarFaltas(){
        faltas += 1;
        if (faltas==5) {
            expulsado = true;
        }//if
    }//sumarFaltas
    
    public void sumarPuntos(int numPuntos){
        puntos += numPuntos;
    }//sumarPuntos
    
    public void salirBanquillo(){
        if (banquillo==true) {
            banquillo = false;
        }else{
            banquillo = true;
        }//ifelse
    }//salirBanquillo
    
    public void imprimirDatos(){
        System.out.println("Nombre: "+nombreJugador);
        System.out.println("Altura: "+altura);
        System.out.println("Puntos: "+puntos);
        System.out.println("Faltas: "+faltas);
    }//imprimirDatos
    
}//Jugador
