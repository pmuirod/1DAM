/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package examenejercicio1;

/**
 *
 * @author Pablo Muiño Rodríguez
 */
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        //Se crean las variables que se van a utilizar en la clase main
        String nombreClub, respuesta, nombre;
        int categoria, altura, posicion;
        
        //Se crea un objeto scanner para recoger lo que el usuario introduce por teclado
        Scanner sc = new Scanner(System.in);
        
        //Se crean 3 jugadores
        Jugador j1 = new Jugador("Juan",1.69);
        Jugador j2 = new Jugador("Antonio",2.05,4);
        Jugador j3 = new Jugador("Alberto",1.92,3);

        //Se crea el contenido de la clase main
        System.out.println("Indique el nombre del club:");
        nombreClub = sc.nextLine();
        System.out.println("Indique la categoría del club:");
        categoria = sc.nextInt();
        while (categoria<1 | categoria>4) {
            System.out.println("Se han introducido mal los datos (sólo hay categorías del 1 al 4)");
            System.out.println("Vuelva a introducir la categoría:");
            categoria = sc.nextInt();
        }//while
        
        System.out.println("---*Partido X*---");
        System.out.println(j1.getNombreJugador()+" ha anotado 2 puntos");
        j1.sumarPuntos(2);
        System.out.println(j1.getNombreJugador()+" ha cometido su primera falta");
        j1.sumarFaltas();
        System.out.println(j2.getNombreJugador()+" ha anotado 1 punto");
        j2.sumarPuntos(1);
        System.out.println(j1.getNombreJugador()+" ha cometido su segunda falta");
        j1.sumarFaltas();
        System.out.println(j3.getNombreJugador()+" ha anotado 3 puntos");
        j3.sumarPuntos(3);
        System.out.println(j3.getNombreJugador()+" ha cometido su primera falta");
        j3.sumarFaltas();
        
        System.out.println("");
        System.out.println("Resultados del partido:");
        System.out.println("Nombre: "+j1.getNombreJugador());
        System.out.print("Altura: ");
        System.out.printf("%.2f",j1.getAltura());
        System.out.println("");
        System.out.println("Puntos: "+j1.getPuntos());
        System.out.println("Faltas: "+j1.getFaltas());
        System.out.println("");
        System.out.println("Nombre: "+j2.getNombreJugador());
        System.out.print("Altura: ");
        System.out.printf("%.2f",j2.getAltura());
        System.out.println("");
        System.out.println("Puntos: "+j2.getPuntos());
        System.out.println("Faltas: "+j2.getFaltas());
        System.out.println("");
        System.out.println("Nombre: "+j2.getNombreJugador());
        System.out.print("Altura: ");
        System.out.printf("%.2f",j2.getAltura());
        System.out.println("");
        System.out.println("Puntos: "+j2.getPuntos());
        System.out.println("Faltas: "+j2.getFaltas());
        
    }//main
}//Main
