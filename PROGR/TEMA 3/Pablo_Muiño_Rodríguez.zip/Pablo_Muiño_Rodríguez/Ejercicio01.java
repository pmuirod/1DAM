/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio01;

/**
 *
 * @author Pablo Muiño Rodríguez
 */
import java.util.Scanner;

//Para realizar este ejercicio lo primero que hago es pedir al usuario un texto y después voy asigando a una variable String palabra por palabra
//usando el concepto de que las palabras se separan por espacios. Después comprubo la longitud de la variable para saber si tiene menos o mas de 5 carácteres.
//Contabilizo las palabras de cada tipo y las totales (cuantas palabras hay en el texto) y con estos dos datos hago el porcentaje correspondiente. Por último
//escribo el número de palabras de cada tipo y su porcentaje.
public class Ejercicio01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Se definen las variables que se van a utilizar en el ejercicio
        String muiñoTexto;
        String muiñoPalabra;
        
        //Se crea un objeto Scanner para recoger lo escrito por teclado
        Scanner sc = new Scanner(System.in);
        
        //Se indica que es lo que tiene que introdducir por teclado el usuario
        System.out.println("Escriba un texto:");
        muiñoTexto = sc.nextLine();
        
        //Se realizan las condiciones y/bucles
        
        
    }//main
    
}//calss
